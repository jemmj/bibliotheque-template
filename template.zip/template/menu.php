
<nav class="navbar navbar-expand-lg ">
  
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
							<span class="navbar-toggler-icon"></span>
						</button>

				<div class="collapse navbar-collapse" id="navbar-nav">
						
						<ul class="navbar-nav">

					<!--logo intense-->						
										<li class="nav-item active">
											<img class="logo" src="img/logo.jpg">
										</li>

					<!--titre home-->

										<li class="nav-item active">

											<a class="nav-link" id="titrehome"href="#">Home</a> 
											<div class="msborder"></div>
											
										</li>
									  
  					<!--titre features-->
     							 		<li class="nav-item">
       								 		<a class="nav-link" id="titrefeatures" href="#">Features</a>
       								 		<div class="msborder"></div>
      									</li>

      									<li class="nav-item">
        									<a class="nav-link" id="titrepages"href="#">Pages</a>
        									<div class="msborder"></div>
        								</li>


				
        			<!--titre portfolio-->
   							   			<li class="nav-item">
        									<a class="nav-link" href="#">Portfolio</a>
        									<div class="msborder"></div>
      									</li>
      				<!--titre blog-->
	  									<li class="nav-item">
       							 			<a class="nav-link" href="#">Blog</a> 
       							 			<div class="msborder"></div>		
     									</li>
     				<!--titre shop-->
	 						 			<li class="nav-item">
      						  				<a class="nav-link" href="#">Shop</a>
      						  				<div class="msborder"></div>			
      									</li>
      				<!--titre components-->
	  									<li class="nav-item">
       										 <a class="nav-link" href="#">Components</a>
       										 <div class="msborder"></div>				
      									</li>
      				<!--lien de recherche -->
	  									<li class="nav-item">
       						 				<a class="nav-link" href="#">
       						 				<img class="loupe" src="img/loupe.jpg"></a>
      									</li>
      				<!--lien panier -->
										<li class="nav-item">
        								<a class="nav-link" href="#"><img class="achat" src="img/achat.jpg"></a>
      									</li>
    	</ul>
  </div>
  
</nav>